# PerAlessio
# Contains fifteen function and two data frame.

## Sei la ragione per cui
indovina1 <- function(canzone,titolo,artista) {
  if (canzone == "sto bene") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Sto bene") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Psicologi") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Stavamo girando
indovina2 <- function(canzone,titolo,artista) {
  if (canzone == "due storie") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "M12ano") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Tha Supreme") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Sento il tuo cuore
indovina3 <- function(canzone,titolo,artista) {
  if (canzone == "battere col mio") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Girasole") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Cicco Sanchez") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Che ovunque vada
indovina4 <- function(canzone,titolo,artista) {
  if (canzone == "io cerchero te") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Wanderlust") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Alfa") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Affondiamo
indovina5 <- function(canzone,titolo,artista) {
  if (canzone == "fra mille emozioni") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Salvami") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Anzj") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Salto nel vuoto
indovina6 <- function(canzone,titolo,artista) {
  if (canzone == "vieni con me") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Le luci della citt?") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Coez") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Ma nulla ha senso se
indovina7 <- function(canzone,titolo,artista) {
  if (canzone == "poi non ci sei te") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Carillon") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Mr.Rain") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Prometti che non
indovina8 <- function(canzone,titolo,artista) {
if (canzone == "scappi via anche tu") {
  print ("Ti")
} else {
  print ("Wuf")
}
if (titolo == "Tutto per me") {
  print ("Ti")
} else {
  print ("Wuf")
}
if (artista == "Michele") {
  print ("Ti")
} else {
  print ("Wuf")
}
}

## Se ti senti male

indovina9 <- function(canzone,titolo,artista) {
  if (canzone == "baby chiama me") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Cenere") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Nashley") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Amore mio
indovina10 <- function(canzone,titolo,artista) {
  if (canzone == "da dove vengo io") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Lake Washington Boulevard") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Pinguini tattici nucleari") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Quando ti vedo
indovina11 <- function(canzone,titolo,artista) {
  if (canzone == "non vedo pi? la tristezza") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Festa") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Psicologi") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Le coperte non le voglio
indovina12 <- function(canzone,titolo,artista) {
  if (canzone == "perch? coprono l'orgoglio") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Chic") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Izi") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Sul letto ho retto
indovina13 <- function(canzone,titolo,artista) {
  if (canzone == "l'eco di che pensi") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Solletico") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Rkomi") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Anche se a volte ora
indovina14 <- function(canzone,titolo,artista) {
  if (canzone == "mi chiedo dove sei") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (titolo == "Dove sei") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Alfa") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
}

## Ho sognato che ti avevo perso
indovina15 <- function(canzone,artista) {
  if (canzone == "per fortuna questo non fa testo") {
    print ("Ti")
  } else {
    print ("Wuf")
  }
  if (artista == "Alessio") {
    print ("Mio")
  } else {
    print ("Wuf")
  }
}

## giochino[1,]
giochino<-data.frame(
  funzione = c("indovina1","indovina2","indovina3",
               "indovina4","indovina5","indovina6",
               "indovina7","indovina8","indovina9",
               "indovina10","indovina11","indovina12",
               "indovina13","indovina14","indovina15"),
  canzone = c("Sei la ragione per cui","Stavamo girando","Sento il tuo cuore",
              "Che ovunque vada","Affondiamo","Salto nel vuoto",
              "Ma nulla ha senso se","Prometti che non","Se ti senti male",
              "Amore mio","Quando ti vedo","Le coperte non le voglio",
              "Sul letto ho retto","Anche se a volte ora","Ho sognato che ti avevo perso")
)

## ale
ale<-data.frame("ti" = c("amo", "pfff"),
                "mi" = c("manchi","tantissimo"),
                "sei" = c("davvero","speciale"),
                "Sei" = c("solo","mio")
                )
